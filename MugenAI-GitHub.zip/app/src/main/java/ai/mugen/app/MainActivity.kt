package ai.mugen.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding

class MainActivity : AppCompatActivity() {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        addMessage("Mugen.AI", "Halo! Aku Mugen.AI 👋\nTulis pertanyaanmu di bawah.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(15, 17, 23))
        }

        val title = TextView(this).apply {
            text = "Mugen.AI"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(20)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 70))

        val scroll = ScrollView(this)
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16)
        }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply {
            setPadding(12)
        }
        input = EditText(this).apply {
            hint = "Tanya Mugen.AI..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(35, 38, 48))
            setPadding(16)
        }
        val send = Button(this).apply {
            text = "Kirim"
            setOnClickListener { sendMessage() }
        }
        row.addView(input, LinearLayout.LayoutParams(0, 60, 1f))
        row.addView(send, LinearLayout.LayoutParams(110, 60))
        root.addView(row)

        setContentView(root)
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return

        addMessage("Kamu", text)
        input.text.clear()

        val reply = when {
            text.contains("halo", true) || text.contains("hai", true) ->
                "Halo! 👋 Ada yang bisa Mugen bantu?"
            text.contains("belajar", true) ->
                "Tentu. Kirim materi atau pertanyaan yang ingin kamu pelajari."
            text.contains("siapa", true) ->
                "Aku Mugen.AI, asisten belajar versi awal."
            else ->
                "Aku menerima pesanmu: "$text"\n\nVersi ini masih memakai respons demo. Backend AI bisa ditambahkan nanti."
        }
        addMessage("Mugen.AI", reply)
    }

    private fun addMessage(sender: String, message: String) {
        val tv = TextView(this).apply {
            text = "$sender\n$message"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(18)
            setBackgroundColor(Color.rgb(35, 38, 48))
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 0, 0, 16)
        }
        chat.addView(tv, params)
    }
}
