# Mugen.AI

A simple Android AI chat starter project.

## Features
- Modern chat interface
- Local demo responses so the app runs without an API key
- Clean structure for adding a real AI backend later
- GitHub Actions workflow for building a debug APK

## Open in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run the `app` configuration on an emulator/device.
4. Build the APK with `./gradlew assembleDebug`.

## Important
Do not put an AI API key directly inside the Android app. For production, call your own backend and keep the secret key on the server.
